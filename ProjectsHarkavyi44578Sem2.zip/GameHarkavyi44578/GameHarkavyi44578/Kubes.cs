﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.Threading.Tasks;

namespace GameHarkavyi44578
{
    class Kubes
    {
        private int lastX;
        public Rectangle[,] kubs;
        public Color[,] kColor;
        public int[] colors;
        public Point dim;
        public int score;
        Random r = new Random();

        public Kubes(int x, int y)
        {
            dim = new Point(x, y);
            lastX=x;
            kubs = new Rectangle[x, y];
            kColor = new Color[x, y];
            colors = new int[4]{0,0,0,0};
            genArr(x, y);
        }
        void genArr(int x, int y)
        {
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    kubs[i, j] = new Rectangle(i * 25, j * 25, 22, 22);
                    kColor[i, j] = new Color();
                    Color cl = new Color();
                    cl = Color.Blue;
                    switch (r.Next(0, 4))
                    {
                        case 0:
                            {
                                kColor[i, j] = Color.Red;
                                colors[0]++;
                                break;
                            }
                        case 1:
                            {
                                kColor[i, j] = Color.Green;
                                colors[1]++;
                                break;
                            }
                        case 3:
                            {
                                kColor[i, j] = Color.Blue;
                                colors[2]++;
                                break;
                            }
                        default:
                            {
                                kColor[i, j] = Color.Yellow;
                                colors[3]++;
                                break;
                            }
                    }
                }
            }
        }
        public List<Point> getList(Point selectedPoin)
        {
            List<Point> list = new List<Point>();
            Point p = new Point();
            if (selectedPoin.X % 25 >= 0 && selectedPoin.X % 25 <= 22 && selectedPoin.Y % 25 >= 0 && selectedPoin.Y % 25 <= 22)
            {
                p.X = (int)selectedPoin.X / 25;
                p.Y = (int)selectedPoin.Y / 25;
                list.Add(p);
                selection(p, list);
                return list;
            }
            else return list;
        }
        private List<Point> selection(Point entryP, List<Point> list)
        {
            Point tmp = new Point();
            if (kColor[entryP.X, entryP.Y] != Color.White)
            {
                tmp.X = entryP.X + 1;
                tmp.Y = entryP.Y;
                if (tmp.X >= 0 && tmp.X < dim.X && tmp.Y >= 0 && tmp.Y < dim.Y)
                {
                    if (kColor[entryP.X, entryP.Y] == kColor[tmp.X, tmp.Y] && list.Contains(tmp) != true)
                    {
                        list.Add(tmp);
                        selection(tmp, list);
                    }
                }
                tmp.X = entryP.X - 1;
                tmp.Y = entryP.Y;
                if (tmp.X >= 0 && tmp.X < dim.X && tmp.Y >= 0 && tmp.Y < dim.Y)
                {
                    if (kColor[entryP.X, entryP.Y] == kColor[tmp.X, tmp.Y] && list.Contains(tmp) != true)
                    {
                        list.Add(tmp);
                        selection(tmp, list);
                    }
                }
                tmp.X = entryP.X;
                tmp.Y = entryP.Y + 1;
                if (tmp.X >= 0 && tmp.X < dim.X && tmp.Y >= 0 && tmp.Y < dim.Y)
                {
                    if (kColor[entryP.X, entryP.Y] == kColor[tmp.X, tmp.Y] && list.Contains(tmp) != true)
                    {
                        list.Add(tmp);
                        selection(tmp, list);
                    }
                }
                tmp.X = entryP.X;
                tmp.Y = entryP.Y - 1;
                if (tmp.X >= 0 && tmp.X < dim.X && tmp.Y >= 0 && tmp.Y < dim.Y)
                {
                    if (kColor[entryP.X, entryP.Y] == kColor[tmp.X, tmp.Y] && list.Contains(tmp) != true)
                    {
                        list.Add(tmp);
                        selection(tmp, list);
                    }
                }
            }
            return list;
        }
        public void delete(List<Point> list)
        {
            if(list.Count > 1)
            {
                if (kColor[list[0].X, list[0].Y] == Color.Red) { colors[0] -= list.Count; }
                if (kColor[list[0].X, list[0].Y] == Color.Green) { colors[1] -= list.Count; }
                if (kColor[list[0].X, list[0].Y] == Color.Blue) { colors[2] -= list.Count; }
                if (kColor[list[0].X, list[0].Y] == Color.Yellow) { colors[3] -= list.Count; }
                score += (int)Math.Pow(2,list.Count);
                for (int i = 0; i < list.Count; i++)
                {
                    kColor[list[i].X, list[i].Y] = Color.White;
                }
            }
        }
        public void drop()
        {
            for (int i = 0; i < lastX; i++)
            {
                for (int j = 0; j < dim.Y; j++)
                {
                    if (kColor[i, j] == Color.White)
                    {
                        for (int k = j; k >= 0; k--)
                        {
                            if (k > 0)
                            {
                                kColor[i, k] = kColor[i, k - 1];
                            }
                            else
                            {
                                kColor[i, k] = Color.White;
                            }
                        }
                    }
                }
            }
            for (int i = lastX-1; i > 0; i--)
            {
                if (kColor[i, dim.Y - 1] == Color.White)
                {
                    slide(i);
                }
            }
        }
        private void slide(int x)
        {
            for (int i = x; i < lastX-1; i++)
            {
                for (int j = 0; j < dim.Y; j++)
                {
                    kColor[i, j] = kColor[i+1, j];
                }
            }
            for (int i = 0; i < dim.Y; i++)
            {
                kColor[lastX - 1, i] = Color.White;
            }
            lastX--;
        }
    }
}
