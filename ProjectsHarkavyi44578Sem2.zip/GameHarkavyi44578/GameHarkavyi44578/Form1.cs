﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace GameHarkavyi44578
{
    public partial class Form1 : Form
    {
        Bitmap Ref = new Bitmap(Properties.Resources.rsz_coobiks);
        Point pos = new Point(0,0);
        Kubes elem;
        Bitmap tmp;
        Point dim = new Point(21, 21);
        SolidBrush sb;
        Graphics GF, GB;
        Form2 setting = new Form2();
        Form3 about = new Form3();
        
        public Form1()
        {
            InitializeComponent();
            this.SetBounds(100, 100, dim.X * 25+20, dim.Y * 25 + 90);
            tmp = new Bitmap(dim.X * 25 - 2, dim.Y * 25 - 2);
            GF = this.CreateGraphics();
            GB = Graphics.FromImage(tmp);
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            generate();
            draw();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            draw();
            this.Refresh();
        }

        private void Form1_MouseClick(object sender, MouseEventArgs e)
        {
            pos.X = Cursor.Position.X - 10;
            pos.Y = Cursor.Position.Y - 60;
            elem.delete(elem.getList(this.PointToClient(pos)));
            elem.drop();
            draw();
            label1.Text = elem.colors[0].ToString();
            label2.Text = elem.colors[1].ToString();
            label3.Text = elem.colors[2].ToString();
            label4.Text = elem.colors[3].ToString();
            label5.Text = "Score: " + elem.score.ToString();
        }

        private void generate()
        {
            elem = new Kubes(dim.X,dim.Y);
        }
        private void draw()
        {
            GB.Clear(this.BackColor);
            for (int i = 0; i < dim.X; i++)
            {
                for (int j = 0; j < dim.Y; j++)
                {
                    if (elem.kColor[i, j] != Color.White)
                    {
                        sb = new SolidBrush(elem.kColor[i, j]);
                        GB.FillRectangle(sb, elem.kubs[i, j]);
                        GB.DrawRectangle(Pens.Black, elem.kubs[i, j]);
                    }
                }
            }
            GF.DrawImage(tmp, 10, 60);
        }


        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            generate();
            draw();
        }

        private void settingsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (setting.ShowDialog() == DialogResult.OK)
            {
                dim.X = setting.x;
                dim.Y = setting.y;
                this.SetBounds(10, 10, dim.X * 25 + 20, dim.Y * 25 + 90);
                GF.Clear(this.BackColor);
                tmp = new Bitmap(dim.X * 25 - 2, dim.Y * 25 - 2);
                GF = this.CreateGraphics();
                GB = Graphics.FromImage(tmp);

                generate();
                draw();

            }
        }
        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();

        }

        private void aboutAutorToolStripMenuItem_Click(object sender, EventArgs e)
        {
            about.ShowDialog();
        }




    }
}
