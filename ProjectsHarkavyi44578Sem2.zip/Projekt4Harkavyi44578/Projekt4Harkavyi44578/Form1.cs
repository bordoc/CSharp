﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt4Harkavyi44578
{
    public partial class Form1 : Form
    {
        Dictionary<string, List<Figure>> dict = new Dictionary<string, List<Figure>>();
        Figure tmpFigure;
        bool isDrawing = false;
        Point mousePos = new Point();
        Graphics g, gBuff, gBuff2;
        Bitmap buff, buff2;
        Pen pen = new Pen(Color.Black, 2);
        SolidBrush brush = new SolidBrush(Color.Black);
        Rect rect;

        public Form1()
        {
            InitializeComponent();
            g = pictureBox1.CreateGraphics();
            g.Clear(Color.White);
            rect = new Rect(pen, (SolidBrush)brush);
            buff = new Bitmap(pictureBox1.Bounds.Width, pictureBox1.Bounds.Height);
            buff2 = new Bitmap(pictureBox1.Bounds.Width, pictureBox1.Bounds.Height);
            gBuff = Graphics.FromImage(buff);
            gBuff2 = Graphics.FromImage(buff2);
            gBuff.Clear(Color.Transparent);
            gBuff2.Clear(pictureBox1.BackColor);
            tmpFigure = new Rect(pen, brush);
            ReNewFigure();
            comboBox1.SelectedIndex = 0;
        }

        void Draw()
        {
            g.DrawImage(buff, 0, 0);
        }

        void ReDraw()
        {
            gBuff2.Clear(pictureBox1.BackColor);
            foreach (string str in dict.Keys)
            {
                foreach (Figure fig in dict[str])
                {
                    fig.Redraw(gBuff2);
                }
            }
            g.DrawImage(buff2, 0, 0);
        }

        void EditSelectedFigure()
        {
            if (dict.Keys.Count > 0)
            {
                Figure tmp;
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                tmp = dict[typeName][index];
                if (radioButton7.Checked)
                {
                    tmp.isFilled = true;
                }
                else
                {
                    tmp.isFilled = false;
                }

                tmp.pen.Color = panel2.BackColor;
                tmp.brush.Color = panel3.BackColor;

                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                        break;
                    case 1:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                        break;
                    case 2:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                        break;
                    case 3:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
                        break;
                    case 4:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                        break;
                }

                tmp.pen.Width = trackBar5.Value;
                tmp.MoveX(trackBar1.Value);
                tmp.MoveY(trackBar2.Value);
                tmp.ScaleX(trackBar3.Value);
                tmp.ScaleY(trackBar4.Value);
                dict[typeName][index] = tmp;
                ReDraw();
            }
        }

        void ReNewFigure()
        {
            if (radioButton1.Checked)
            {
                tmpFigure = new Rect(new Pen(panel2.BackColor, trackBar5.Value), new SolidBrush(panel3.BackColor));
            }
            if (radioButton2.Checked)
            {
                tmpFigure = new Square(new Pen(panel2.BackColor, trackBar5.Value), new SolidBrush(panel3.BackColor));
            }
            if (radioButton3.Checked)
            {
                tmpFigure = new Ellipse(new Pen(panel2.BackColor, trackBar5.Value), new SolidBrush(panel3.BackColor));
            }
            if (radioButton4.Checked)
            {
                tmpFigure = new Circle(new Pen(panel2.BackColor, trackBar5.Value), new SolidBrush(panel3.BackColor));
            }
            if (radioButton5.Checked)
            {
                tmpFigure = new MyPen(new Pen(panel2.BackColor, trackBar5.Value), new SolidBrush(panel3.BackColor));
            }
            if (radioButton6.Checked)
            {
                tmpFigure = new Line(new Pen(panel2.BackColor, trackBar5.Value), new SolidBrush(panel3.BackColor));
            }

            if (radioButton7.Checked)
            {
                tmpFigure.isFilled = true;
            }
            else
            {
                tmpFigure.isFilled = false;
            }

            tmpFigure.pen.Color = panel2.BackColor;
            tmpFigure.brush.Color = panel3.BackColor;

            switch (comboBox1.SelectedIndex)
            {
                case 0:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    break;
                case 1:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                    break;
                case 2:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                    break;
                case 3:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
                    break;
                case 4:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    break;
            }
        }

        void Clear()
        {
            gBuff2.Clear(pictureBox1.BackColor);
            foreach (string str in dict.Keys)
            {
                dict[str].Clear();
            }
            dict.Clear();
            listBox1.Items.Clear();
            ReDraw();
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            label5.Text = e.X.ToString() + "; " + e.Y.ToString();
            mousePos.X = e.X;
            mousePos.Y = e.Y;
            if (isDrawing)
            {
                gBuff.Clear(Color.Transparent);
                gBuff.DrawImage(buff2, 0, 0);
                tmpFigure.Draw(mousePos, gBuff);
                Draw();
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            isDrawing = true;
            ReNewFigure();
            tmpFigure.BeginDraw(new Point(e.X, e.Y));
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            if (isDrawing)
            {
                isDrawing = false;
                gBuff2.DrawImage(buff, 0, 0);
                if (!dict.ContainsKey(tmpFigure.ToString()))
                {
                    dict.Add(tmpFigure.ToString(), new List<Figure>());
                }
                dict[tmpFigure.ToString()].Add(tmpFigure);
                listBox1.Items.Add(tmpFigure.ToString()+ "_" + dict[tmpFigure.ToString()].IndexOf(tmpFigure).ToString());
                listBox1.SelectedIndex = listBox1.Items.Count - 1;
                ReNewFigure();
            }
        }

        private void radioButton5_CheckedChanged(object sender, EventArgs e)
        {
            ReNewFigure();
        }

        private void panel2_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel2.BackColor = colorDialog1.Color;
                EditSelectedFigure();
            }
        }

        private void panel3_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel3.BackColor = colorDialog1.Color;
                EditSelectedFigure();
            }
        }

        private void panel4_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel4.BackColor = colorDialog1.Color;
                pictureBox1.BackColor = colorDialog1.Color; 
                ReDraw();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            EditSelectedFigure();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            EditSelectedFigure();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                Figure tmp;
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                tmp = dict[typeName][index];
                panel2.BackColor = tmp.pen.Color;
                panel3.BackColor = tmp.brush.Color;
                switch (tmp.pen.DashStyle)
                {
                    case System.Drawing.Drawing2D.DashStyle.Solid:
                        comboBox1.SelectedIndex = 0;
                        break;
                    case System.Drawing.Drawing2D.DashStyle.Dot:
                        comboBox1.SelectedIndex = 1;
                        break;
                    case System.Drawing.Drawing2D.DashStyle.DashDotDot:
                        comboBox1.SelectedIndex = 2;
                        break;
                    case System.Drawing.Drawing2D.DashStyle.DashDot:
                        comboBox1.SelectedIndex = 3;
                        break;
                    case System.Drawing.Drawing2D.DashStyle.Dash:
                        comboBox1.SelectedIndex = 4;
                        break;
                }
                trackBar5.Value = (int)tmp.pen.Width;
                if (tmp.isFilled)
                {
                    radioButton7.Checked = true;
                }
                else
                {
                    radioButton8.Checked = true;
                }
                trackBar1.Value = tmp.pos.X;
                trackBar2.Value = tmp.pos.Y;
                trackBar3.Value = 1;
                trackBar4.Value = 1;
            }
            catch { }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Clear();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            saveFileDialog1.Filter = "Bitmap Image|*.bmp";
            if (saveFileDialog1.ShowDialog() == DialogResult.OK)
            {
                buff2.Save(saveFileDialog1.FileName);
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.Filter = "Bitmap Image|*.bmp";
            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                Clear();
                g.DrawImage(Image.FromFile(openFileDialog1.FileName), 0, 0);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                dict[typeName].RemoveAt(index);
                listBox1.Items.Clear();
                foreach (string str in dict.Keys)
                {
                    for (int i = 0; i < dict[str].Count; i++)
                    {
                        listBox1.Items.Add(dict[str][i].ToString() + "_" + i);
                    }
                }
                ReDraw();
            }
            catch { }
        }

        private void radioButton7_CheckedChanged(object sender, EventArgs e)
        {
            EditSelectedFigure();
        }
    }
}
