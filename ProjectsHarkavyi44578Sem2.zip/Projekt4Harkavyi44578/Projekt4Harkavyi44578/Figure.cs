﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt4Harkavyi44578
{
    class Figure
    {
        protected Point startpos;
        public Point pos;
        public int width, height;
        public bool isFilled = false;
        public Pen pen;
        public SolidBrush brush;

        public Figure(Pen p, SolidBrush b)
        {
            pen = p;
            brush = b;
        }

        public virtual void BeginDraw(Point start)
        {
            startpos = start;
        }

        public virtual void Draw(Point currPos, Graphics g)
        {
            int dX, dY;
            dX = startpos.X - currPos.X;
            dY = startpos.Y - currPos.Y;
            if (dX > 0)
            {
                if (dY > 0)
                {
                    _Draw(currPos.X, currPos.Y, dX, dY, g);
                    pos = new Point(currPos.X, currPos.Y);
                    width = dX;
                    height = dY;
                }
                else
                {
                    _Draw(currPos.X, startpos.Y, dX, -dY, g);
                    pos = new Point(currPos.X, startpos.Y);
                    width = dX;
                    height = -dY;
                }
            }
            else
            {
                if (dY > 0)
                {
                    _Draw(startpos.X, currPos.Y, -dX, dY, g);
                    pos = new Point(startpos.X, currPos.Y);
                    width = -dX;
                    height = dY;
                }
                else
                {
                    _Draw(startpos.X, startpos.Y, -dX, -dY, g);
                    pos = new Point(startpos.X, startpos.Y);
                    width = -dX;
                    height = -dY;
                }
            }
        }

        public virtual void Redraw(Graphics g)
        {

        }

        public virtual void MoveX(int x)
        {
            pos.X = x;
        }

        public virtual void MoveY(int y)
        {
            pos.Y = y;
        }

        public virtual void ScaleX(float x)
        {
            width = (int)(width * x);
        }

        public virtual void ScaleY(float y)
        {
            height = (int)(height * y);
        }

        protected virtual void _Draw(int x, int y, int width, int height, Graphics g)
        {

        }
    }

    class Rect : Figure
    {
        public Rect(Pen p, SolidBrush b)
            : base(p, b)
        { }
        protected override void _Draw(int x, int y, int width, int height, Graphics g)
        {
            if (isFilled)
            {
                g.FillRectangle(brush, x, y, width, height);
            }
            else
            {
                g.DrawRectangle(pen, x, y, width, height);
            }
        }

        public override void Redraw(Graphics g)
        {
            if (isFilled)
            {
                g.FillRectangle(brush, pos.X, pos.Y, width, height);
            }
            else
            {
                g.DrawRectangle(pen, pos.X, pos.Y, width, height);
            }
        }

        public override string ToString()
        {
            return "Rectangle";
        }
    }

    class Square: Figure
    {
        public Square(Pen p, SolidBrush b)
            : base(p, b)
        { }

        public override void BeginDraw(Point start)
        {
            pos = start;
        }

        public override void Draw(Point currPos, Graphics g)
        {
            int dx = Math.Abs(currPos.X - pos.X);
            int dy = Math.Abs(currPos.Y - pos.Y);
            if (dx < dy)
            {
                dx = dy;
            }
            width = dx;
            height = dx;
            if (isFilled)
            {
                g.FillRectangle(brush, pos.X, pos.Y, dx, dx);
            }
            else
            {
                g.DrawRectangle(pen, pos.X, pos.Y, dx, dx);
            }
        }

        public override void Redraw(Graphics g)
        {
            if (isFilled)
            {
                g.FillRectangle(brush, pos.X, pos.Y, width, height);
            }
            else
            {
                g.DrawRectangle(pen, pos.X, pos.Y, width, height);
            }
        }

        public override string ToString()
        {
            return "Square";
        }
    }

    class Ellipse : Figure
    {
        public Ellipse(Pen p, SolidBrush b)
            : base(p, b)
        { }
        protected override void _Draw(int x, int y, int width, int height, Graphics g)
        {
            if (isFilled)
            {
                g.FillEllipse(brush, x, y, width, height);
            }
            else
            {
                g.DrawEllipse(pen, x, y, width, height);
            }
        }

        public override void Redraw(Graphics g)
        {
            if (isFilled)
            {
                g.FillEllipse(brush, pos.X, pos.Y, width, height);
            }
            else
            {
                g.DrawEllipse(pen, pos.X, pos.Y, width, height);
            }
        }

        public override string ToString()
        {
            return "Ellipse";
        }
    }

    class Circle : Figure
    {
        public Circle(Pen p, SolidBrush b)
            : base(p, b)
        { }

        public override void BeginDraw(Point start)
        {
            pos = start;
        }

        public override void Draw(Point currPos, Graphics g)
        {
            int dx = Math.Abs(currPos.X - pos.X);
            int dy = Math.Abs(currPos.Y - pos.Y);
            if (dx < dy)
            {
                dx = dy;
            }
            width = dx;
            height = dx;
            if (isFilled)
            {
                g.FillEllipse(brush, pos.X, pos.Y, dx, dx);
            }
            else
            {
                g.DrawEllipse(pen, pos.X, pos.Y, dx, dx);
            }
        }

        public override void Redraw(Graphics g)
        {
            if (isFilled)
            {
                g.FillEllipse(brush, pos.X, pos.Y, width, height);
            }
            else
            {
                g.DrawEllipse(pen, pos.X, pos.Y, width, height);
            }
        }

        public override string ToString()
        {
            return "Circle";
        }
    }

    class MyPen : Figure
    {
        List<Point> list = new List<Point>();
        public MyPen(Pen p, SolidBrush b)
            : base(p, b)
        { }

        public override void BeginDraw(Point start)
        {
            pos = start;
            list.Add(new Point(0, 0));
        }

        public override void Draw(Point currPos, Graphics g)
        {
            list.Add(new Point(currPos.X - pos.X, currPos.Y - pos.Y));
            Point last = list[0];
            foreach (Point p in list)
            {
                g.DrawLine(pen, new Point(p.X + pos.X, p.Y + pos.Y),
                    new Point(last.X + pos.X, last.Y + pos.Y));
                last = p;
            }
        }

        public override void Redraw(Graphics g)
        {
            Point last = list[0];
            foreach (Point p in list)
            {
                g.DrawLine(pen, new Point(p.X + pos.X, p.Y + pos.Y),
                    new Point(last.X + pos.X, last.Y + pos.Y));
                last = p;
            }
        }

        public override void MoveX(int x)
        {
            pos.X = x;
        }

        public override void MoveY(int y)
        {
            pos.Y = y;
        }

        public override void ScaleX(float x)
        {
            Point tmp;
            for (int i = 0; i < list.Count; i++)
            {
                tmp = list[i];
                tmp.X = (int)(tmp.X * x);
                list[i] = tmp;
            }
        }

        public override void ScaleY(float y)
        {
            Point tmp;
            for (int i = 0; i < list.Count; i++)
            {
                tmp = list[i];
                tmp.Y = (int)(tmp.Y * y);
                list[i] = tmp;
            }
        }

        public override string ToString()
        {
            return "Pen";
        }
    }

    class Line : Figure
    {
        Point endpos;
        public Line(Pen p, SolidBrush b)
            : base(p, b)
        { }
        
        public override void BeginDraw(Point start)
        {
            pos = start;
            startpos = new Point(0, 0);
        }

        public override void Draw(Point currPos, Graphics g)
        {
            g.DrawLine(pen, pos, currPos);
            endpos = new Point(currPos.X - pos.X, currPos.Y - pos.Y);
        }

        public override void Redraw(Graphics g)
        {
            g.DrawLine(pen, new Point(startpos.X + pos.X, startpos.Y + pos.Y),
                new Point(endpos.X + pos.X, endpos.Y + pos.Y));
        }

        public override void MoveX(int x)
        {
            pos.X = x;
        }

        public override void MoveY(int y)
        {
            pos.Y = y;
        }

        public override void ScaleX(float x)
        {
            endpos.X = (int)(endpos.X * x);
        }

        public override void ScaleY(float y)
        {
            endpos.Y = (int)(endpos.Y * y);
        }

        public override string ToString()
        {
            return "Line";
        }
    }
}
