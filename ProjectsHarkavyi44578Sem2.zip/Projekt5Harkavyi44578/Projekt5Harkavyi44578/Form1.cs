﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt5Harkavyi44578
{
    public partial class Form1 : Form
    {
        Graphics g;
        Graphics gbuff;
        Bitmap buff;
        bool isDown;
        Dictionary<string, List<Mesh>> meshes = new Dictionary<string, List<Mesh>>();
        double focal = 0.014;
        double speed = 0.02;
        Point lastMousPos = new Point();
        public Form1()
        {
            InitializeComponent();
            g = pictureBox1.CreateGraphics();
            buff = new Bitmap(pictureBox1.Bounds.Width, pictureBox1.Bounds.Height);
            gbuff = Graphics.FromImage(buff);
        }

        void Draw()
        {
            gbuff.Clear(pictureBox1.BackColor);
            foreach (string s in meshes.Keys)
            {
                foreach (Mesh m in meshes[s])
                {
                    if (m.isVisible)
                    {
                        m.Draw(gbuff, focal);
                    }
                }
            }
            g.DrawImage(buff, 0, 0);
        }

        void Rotate()
        {
            foreach (string s in meshes.Keys)
            {
                foreach (Mesh m in meshes[s])
                {
                    if (m.isVisible)
                    {
                        m.Rotate(speed);
                    }
                }
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            isDown = true;
        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            isDown = false;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (isDown)
            {

            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            Rotate();
            Draw();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            Mesh tmp;
            try
            {
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        tmp = new Cone(100, 200);
                        tmp.Position = new Vertex(pictureBox1.Bounds.Width / 2, pictureBox1.Bounds.Height / 2, 200);
                        break;
                    case 1:
                        tmp = new Cylinder(100, 200);
                        tmp.Position = new Vertex(pictureBox1.Bounds.Width / 2, pictureBox1.Bounds.Height / 2, 200);
                        break;
                    default:
                        tmp = new Cube();
                        tmp.Position = new Vertex(pictureBox1.Bounds.Width / 2, pictureBox1.Bounds.Height / 2, 200);
                        break;
                }
                if (!meshes.ContainsKey(tmp.ToString()))
                {
                    meshes.Add(tmp.ToString(), new List<Mesh>());
                }
                meshes[tmp.ToString()].Add(tmp);
                RefreshList();
            }
            catch { }
        }
        void RefreshList()
        {
            listBox1.Items.Clear();
            foreach (string s in meshes.Keys)
            {
                foreach (Mesh m in meshes[s])
                {
                    if (m.isVisible)
                    {
                        listBox1.Items.Add(m.ToString() + "_" + meshes[m.ToString()].IndexOf(m).ToString());
                    }
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                meshes[typeName][index].isVisible = !meshes[typeName][index].isVisible;
                Draw();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                meshes[typeName].RemoveAt(index);
                RefreshList();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                meshes[typeName][index].Position = new Vertex(trackBar1.Value, trackBar2.Value, trackBar3.Value);
                Draw();
            }
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                trackBar1.Value = (int)meshes[typeName][index].Position.X;
                trackBar2.Value = (int)meshes[typeName][index].Position.Y;
                trackBar3.Value = (int)meshes[typeName][index].Position.Z;
                Draw();
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                switch (comboBox1.SelectedIndex)
                {
                    case 0:
                        meshes[typeName][index].pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                        break;
                    case 1:
                        meshes[typeName][index].pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                        break;
                    case 2:
                        meshes[typeName][index].pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                        break;
                    case 3:
                        meshes[typeName][index].pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
                        break;
                    case 4:
                        meshes[typeName][index].pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                        break;
                }
                Draw();
            }
        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex >= 0)
            {
                string typeName = listBox1.SelectedItem.ToString().Substring(0, listBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(listBox1.SelectedItem.ToString().Substring(listBox1.SelectedItem.ToString().IndexOf('_') + 1));
                meshes[typeName][index].pen.Width = trackBar4.Value;
                Draw();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            speed = -speed;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            timer1.Enabled = !timer1.Enabled;
        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            speed = 0.01 * trackBar5.Value;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            Rotate();
            Draw();
        }

    }
}
