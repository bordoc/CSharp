﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt5Harkavyi44578
{
    class Cube : Mesh
    {
        List<Face> faces = new List<Face>(4);
        public Cube() : base(0, 0)
        {
            faces.Add(new Face(new Vertex(-50, -50, -50), new Vertex(50, -50, -50),
                new Vertex(50, 50, -50), new Vertex(-50, 50, -50)));

            faces.Add(new Face(new Vertex(-50, -50, 50), new Vertex(50, -50, 50),
                new Vertex(50, 50, 50), new Vertex(-50, 50, 50)));

            faces.Add(new Face(new Vertex(-50, -50, 50), new Vertex(-50, -50, -50),
                new Vertex(-50, 50, -50), new Vertex(-50, 50, 50)));

            faces.Add(new Face(new Vertex(50, -50, -50), new Vertex(50, -50, 50),
                new Vertex(50, 50, 50), new Vertex(50, 50, -50)));
            CalculateOrigin();

        }

        private void CalculateOrigin()
        {
            for (int i = 0; i < faces.Count; i++)
            {
                Vertex tmp = faces[i].GetOrigin();
                origin.X += tmp.X;
                origin.Y += tmp.Y;
                origin.Z += tmp.Z;
            }
            origin.X = origin.X / faces.Count;
            origin.Y = origin.Y / faces.Count;
            origin.Z = origin.Z / faces.Count;
        }



        public override void Draw(Graphics g, double focal)
        {
            foreach (Face f in faces)
            {
                f.DrawFace(g, Position, focal, pen);
            }
        }

        public override void Rotate(double angle)
        {
            for (int i = 0; i < faces.Count; i++)
            {
                faces[i].Rotate(origin, angle);
            }
        }

        public override string ToString()
        {
            return "Cube";
        }
    }
}
