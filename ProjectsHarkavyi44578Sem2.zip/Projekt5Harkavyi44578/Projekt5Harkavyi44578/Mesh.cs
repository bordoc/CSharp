﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt5Harkavyi44578
{
    class Mesh
    {
        public Vertex Position = new Vertex();
        public Pen pen = new Pen(Color.Black, 1);
        protected Vertex origin = new Vertex();
        public bool isVisible = true;
        public Mesh(double Radius, double Width)
        {

        }

        public virtual void Draw(Graphics g, double focal)
        {

        }

        public virtual void Rotate(double angle)
        {

        }
    }
}
