﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt5Harkavyi44578
{
    class Triangle
    {
        Vertex A, B, C;
        Vertex origin = new Vertex();
        public Triangle(Vertex a, Vertex b, Vertex c)
        {
            A = a;
            B = b;
            C = c;
            origin.X = (a.X + b.X + c.X) / 3;
            origin.Y = (a.Y + b.Y + c.Y) / 3;
            origin.Z = (a.Z + b.Z + c.Z) / 3;
        }

        public void DrawFace(Graphics g, Vertex localSpace, double focal, Pen pen)
        {
            Point a = new Point((int)((A.X / ((A.Z + localSpace.Z) * focal)) + localSpace.X), 
                                (int)((A.Y / ((A.Z + localSpace.Z) * focal)) + localSpace.Y));
            Point b = new Point((int)((B.X / ((B.Z + localSpace.Z) * focal)) + localSpace.X), 
                                (int)((B.Y / ((B.Z + localSpace.Z) * focal)) + localSpace.Y));
            Point c = new Point((int)((C.X / ((C.Z + localSpace.Z) * focal)) + localSpace.X), 
                                (int)((C.Y / ((C.Z + localSpace.Z) * focal)) + localSpace.Y));
            g.DrawLine(pen, a, b);
            g.DrawLine(pen, a, c);
            g.DrawLine(pen, b, c);
        }

        public void Rotate(Vertex origin, double angle)
        {
            A.Rotate(origin, angle);
            B.Rotate(origin, angle);
            C.Rotate(origin, angle);
        }

        public Vertex GetOrigin()
        {
            return origin;
        }

        public override string ToString()
        {
            return A.ToString() + ", " + B.ToString() + ", " + C.ToString() + ", " + origin.ToString();
        }
    }
}
