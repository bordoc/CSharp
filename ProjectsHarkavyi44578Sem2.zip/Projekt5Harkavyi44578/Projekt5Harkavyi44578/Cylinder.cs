﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt5Harkavyi44578
{
    class Cylinder : Mesh
    {

        List<Triangle> triangles = new List<Triangle>();
        List<Face> faces = new List<Face>();
        public Cylinder(double Radius, double Height) : base(Radius, Height)
        {
            Generate(Radius, Height);
            CalculateOrigin(Height);
        }

        private void CalculateOrigin(double h)
        {
            for (int i = 0; i < triangles.Count; i++)
            {
                Vertex tmp = triangles[i].GetOrigin();
                origin.X += tmp.X;
                origin.Z += tmp.Z;
            }
            origin.X = origin.X / triangles.Count;
            origin.Y = -h / 2;
            origin.Z = origin.Z / triangles.Count;
        }

        public override void Draw(Graphics g, double focal)
        {
            foreach (Triangle t in triangles)
            {
                t.DrawFace(g, Position, focal, pen);
            }
            foreach (Face f in faces)
            {
                f.DrawFace(g, Position, focal, pen);
            }
        }

        public override void Rotate(double angle)
        {
            foreach (Triangle t in triangles)
            {
                t.Rotate(origin, angle);
            }
        }

        void Generate(double r, double h)
        {
            List<Vertex> botcircle = new List<Vertex>();
            List<Vertex> topcircle = new List<Vertex>();
            double x = Math.Sqrt(r * r / 2);
            Vertex bot = new Vertex(0, h / 2, 0);
            Vertex top = new Vertex(0, -h/2, 0);

            botcircle.Add(new Vertex(0, h / 2, -r));
            botcircle.Add(new Vertex(x, h / 2, -x));
            botcircle.Add(new Vertex(r, h / 2, 0));
            botcircle.Add(new Vertex(x, h / 2, x));
            botcircle.Add(new Vertex(0, h / 2, r));
            botcircle.Add(new Vertex(-x, h / 2, x));
            botcircle.Add(new Vertex(-r, h / 2, 0));
            botcircle.Add(new Vertex(-x, h / 2, -x));

            topcircle.Add(new Vertex(0, -h / 2, -r));
            topcircle.Add(new Vertex(x, -h / 2, -x));
            topcircle.Add(new Vertex(r, -h / 2, 0));
            topcircle.Add(new Vertex(x, -h / 2, x));
            topcircle.Add(new Vertex(0, -h / 2, r));
            topcircle.Add(new Vertex(-x, -h / 2, x));
            topcircle.Add(new Vertex(-r, -h / 2, 0));
            topcircle.Add(new Vertex(-x, -h / 2, -x));

            for (int i = 0; i < botcircle.Count - 1; i++)
            {
                triangles.Add(new Triangle(bot, botcircle[i], botcircle[i + 1]));
                triangles.Add(new Triangle(top, topcircle[i], topcircle[i + 1]));
                faces.Add(new Face(botcircle[i], botcircle[i + 1], topcircle[i + 1], topcircle[i]));
            }
            triangles.Add(new Triangle(bot, botcircle[0], botcircle[botcircle.Count - 1]));
            triangles.Add(new Triangle(top, topcircle[0], topcircle[botcircle.Count - 1]));
        }

        public override string ToString()
        {
            return "Cylinder";
        }
    }
}
