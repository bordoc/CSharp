﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt5Harkavyi44578
{
    class Vertex
    {
        public double X, Y, Z;
        public Vertex(double x, double y, double z)
        {
            X = x;
            Y = y;
            Z = z;
        }

        public Vertex()
        {
            X = 0;
            Y = 0;
            Z = 0;
        }

        public void Rotate(Vertex origin, double angle)
        {
            X -= origin.X;
            Z -= origin.Z;

            double s = Math.Sin(angle);
            double c = Math.Cos(angle);

            double xnew = X * c - Z * s;
            double znew = X * s + Z * c;

            X = origin.X + xnew;
            Z = origin.Z + znew;
        }

        public override string ToString()
        {
            return "(" + Math.Round(X, 2).ToString() + ";" + Math.Round(Y, 2).ToString() + ";" + Math.Round(Z, 2).ToString() + ")";
        }
    }
}
