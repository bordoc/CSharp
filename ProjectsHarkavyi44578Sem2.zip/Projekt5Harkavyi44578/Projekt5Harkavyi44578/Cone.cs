﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt5Harkavyi44578
{
    class Cone : Mesh
    {
        List<Triangle> triangles = new List<Triangle>();
        public Cone(double Radius, double Height) : base(Radius, Height)
        {
            Generate(Radius, Height);
            CalculateOrigin(Height);
        }

        private void CalculateOrigin(double h)
        {
            for (int i = 0; i < triangles.Count; i++)
            {
                Vertex tmp = triangles[i].GetOrigin();
                origin.X += tmp.X;
                origin.Z += tmp.Z;
            }
            origin.X = origin.X / triangles.Count;
            origin.Y = -h / 4;
            origin.Z = origin.Z / triangles.Count;
        }

        public override void Draw(Graphics g, double focal)
        {
            foreach (Triangle t in triangles)
            {
                t.DrawFace(g, Position, focal, pen);
            }
        }

        public override void Rotate(double angle)
        {
            for (int i = 0; i < triangles.Count; i++)
            {
                triangles[i].Rotate(origin, angle);
            }
        }

        void Generate(double r, double h)
        {
            List<Vertex> circle = new List<Vertex>();
            double x = Math.Sqrt(r * r / 2);
            Vertex bot = new Vertex(0, h / 2, 0);
            Vertex top = new Vertex(0, -h/2, 0);
            circle.Add(new Vertex(0, h / 2, -r));
            circle.Add(new Vertex(x, h / 2, -x));
            circle.Add(new Vertex(r, h / 2, 0));
            circle.Add(new Vertex(x, h / 2, x));
            circle.Add(new Vertex(0, h / 2, r));
            circle.Add(new Vertex(-x, h / 2, x));
            circle.Add(new Vertex(-r, h / 2, 0));
            circle.Add(new Vertex(-x, h / 2, -x));
            for (int i = 0; i < circle.Count - 1; i++)
            {
                triangles.Add(new Triangle(bot, circle[i], circle[i + 1]));
                triangles.Add(new Triangle(top, circle[i], circle[i + 1]));
            }
            triangles.Add(new Triangle(bot, circle[0], circle[circle.Count - 1]));
            triangles.Add(new Triangle(top, circle[0], circle[circle.Count - 1]));
        }

        public override string ToString()
        {
            return "Cone";
        }
    }
}
