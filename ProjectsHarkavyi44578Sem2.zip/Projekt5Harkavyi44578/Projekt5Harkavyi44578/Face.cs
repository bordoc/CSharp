﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;
using System.Windows.Forms;

namespace Projekt5Harkavyi44578
{
    class Face
    {
        Vertex A, B, C, D;
        Vertex origin;
        public Face(Vertex a, Vertex b, Vertex c, Vertex d)
        {
            origin = new Vertex();
            A = a;
            B = b;
            C = c;
            D = d;
            origin.X = (a.X + b.X + c.X + d.X) / 4;
            origin.Y = (a.Y + b.Y + c.Y + d.Y) / 4;
            origin.Z = (a.Z + b.Z + c.Z + d.Z) / 4;
        }

        public void DrawFace(Graphics g, Vertex localSpace, double focal, Pen pen)
        {
            Point a = new Point((int)((A.X / ((A.Z + localSpace.Z) * focal)) + localSpace.X), 
                                (int)((A.Y / ((A.Z + localSpace.Z) * focal)) + localSpace.Y));
            Point b = new Point((int)((B.X / ((B.Z + localSpace.Z) * focal)) + localSpace.X), 
                                (int)((B.Y / ((B.Z + localSpace.Z) * focal)) + localSpace.Y));
            Point c = new Point((int)((C.X / ((C.Z + localSpace.Z) * focal)) + localSpace.X), 
                                (int)((C.Y / ((C.Z + localSpace.Z) * focal)) + localSpace.Y));
            Point d = new Point((int)((D.X / ((D.Z + localSpace.Z) * focal)) + localSpace.X), 
                                (int)((D.Y / ((D.Z + localSpace.Z) * focal)) + localSpace.Y));
            g.DrawLine(pen, a, b);
            g.DrawLine(pen, b, c);
            g.DrawLine(pen, c, d);
            g.DrawLine(pen, d, a);
        }

        public void Rotate(Vertex origin, double angle)
        {
            A.Rotate(origin, angle);
            B.Rotate(origin, angle);
            C.Rotate(origin, angle);
            D.Rotate(origin, angle);
        }

        public Vertex GetOrigin()
        {
            return origin;
        }

        public override string ToString()
        {
            return A.ToString() + ", " + B.ToString() + ", " + C.ToString() + ", " + D.ToString() + ", " + origin.ToString();
        }
    }
}
