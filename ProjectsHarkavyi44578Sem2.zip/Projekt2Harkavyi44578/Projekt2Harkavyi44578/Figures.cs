﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt2Harkavyi44578
{
    abstract class Figure
    {
        public List<Point> arr;
        public Point position;
        public Point size;
        public Pen pen;
        public SolidBrush brush;
        public bool filled;

        public Figure()
        {
        }

        public virtual void Draw(Graphics g)
        {

        }
    }

    class Dot : Figure
    {
        public Dot()
        {

        }

        public override void Draw(Graphics g)
        {
            g.FillEllipse(brush, position.X, position.Y, 5, 5);
        }

        public override string ToString()
        {
            return "Dot";
        }
    }

    class Line : Figure
    {
        public Line()
        {
            arr = new List<Point>(2);
            Random rand = new Random();
            arr.Add(new Point(rand.Next(0, 100), rand.Next(0, 100)));
            arr.Add(new Point(rand.Next(0, 100), rand.Next(0, 100)));
        }

        public override void Draw(Graphics g)
        {
            g.DrawLine(pen, new Point(arr[0].X * size.X / 100 + position.X, arr[0].Y * size.Y / 100 + position.Y), 
            new Point(arr[1].X * size.X / 100 + position.X, arr[1].Y * size.Y / 100 + position.Y));
        }

        public override string ToString()
        {
            return "Line";
        }
    }


    class Rect : Figure
    {
        public Rect()
        {

        }

        public override void Draw(Graphics g)
        {
            if (filled)
            {
                g.FillRectangle(brush, position.X, position.Y, size.X, size.Y);
            }
            else
            {
                g.DrawRectangle(pen, position.X, position.Y, size.X, size.Y);
            }
        }

        public override string ToString()
        {
            return "Rectangle";
        }
    }

    class Square : Figure
    {
        public Square()
        {

        }

        public override void Draw(Graphics g)
        {
            if (filled)
            {
                g.FillRectangle(brush, position.X, position.Y, size.X, size.X);
            }
            else
            {
                g.DrawRectangle(pen, position.X, position.Y, size.X, size.X);
            }
        }

        public override string ToString()
        {
            return "Square";
        }
    }

    class Circle : Figure
    {
        public Circle()
        {

        }
        public override void Draw(Graphics g)
        {
            if (filled)
            {
                g.FillEllipse(brush, position.X, position.Y, size.X, size.X);
            }
            else
            {
                g.DrawEllipse(pen, position.X, position.Y, size.X, size.X);
            }
        }

        public override string ToString()
        {
            return "Circle";
        }
    }

    class Ellipse : Figure
    {
        public Ellipse()
        {

        }
        public override void Draw(Graphics g)
        {
            if (filled)
            {
                g.FillEllipse(brush, position.X, position.Y, size.X, size.Y);
            }
            else
            {
                g.DrawEllipse(pen, position.X, position.Y, size.X, size.Y);
            }
        }

        public override string ToString()
        {
            return "Ellipse";
        }
    }

    class Triangle : Figure
    {
        public Triangle()
        {
            arr = new List<Point>(3);
        }
        public override void Draw(Graphics g)
        {
            arr.Clear();
            arr.Add(new Point(0 + position.X, (99 * size.Y / 100) + position.Y));
            arr.Add(new Point(49 * size.X / 100 + position.X, 0 + position.Y));
            arr.Add(new Point(98 * size.X / 100 + position.X, 99 * size.Y / 100 + position.Y));

            if (filled)
            {
                g.FillPolygon(brush, arr.ToArray());
            }
            else
            {
                g.DrawPolygon(pen, arr.ToArray());
            }
        }

        public override string ToString()
        {
            return "Triangle";
        }
    }

    class Pentagon : Figure
    {
        public Pentagon()
        {
            arr = new List<Point>(5);
        }
        public override void Draw(Graphics g)
        {
            arr.Clear();
            arr.Add(new Point(49 * size.X / 100 + position.X, 0 + position.Y));
            arr.Add(new Point(99 * size.X / 100 + position.X, 40 * size.Y / 100 + position.Y));
            arr.Add(new Point(80 * size.X / 100 + position.X, 99 * size.Y / 100 + position.Y));
            arr.Add(new Point(20 * size.X / 100 + position.X, 99 * size.Y / 100 + position.Y));
            arr.Add(new Point(0 + position.X, 40 * size.Y / 100 + position.Y));

            if (filled)
            {
                g.FillPolygon(brush, arr.ToArray());
            }
            else
            {
                g.DrawPolygon(pen, arr.ToArray());
            }
        }

        public override string ToString()
        {
            return "Pentagon";
        }
    }

}
