﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//string str1 = "huy_43".Substring("huy_43".IndexOf('_')+1);

namespace Projekt2Harkavyi44578
{
    public partial class Form1 : Form
    {
        Dictionary<string, List<Figure>> figures = new Dictionary<string,List<Figure>>();
        List<Type> intToType = new List<Type>();
        Random rand = new Random();
        Graphics g;

        public Form1()
        {
            InitializeComponent();
            intToType.Add(typeof(Circle));
            intToType.Add(typeof(Dot));
            intToType.Add(typeof(Ellipse));
            intToType.Add(typeof(Line));
            intToType.Add(typeof(Pentagon));
            intToType.Add(typeof(Triangle));
            intToType.Add(typeof(Rect));
            intToType.Add(typeof(Square));

            foreach (Type type in intToType)
            {
                checkedListBox1.Items.Add(type.ToString().Substring(type.ToString().IndexOf('.') + 1));
                comboBox2.Items.Add(type.ToString().Substring(type.ToString().IndexOf('.') + 1));
            }
            comboBox2.SelectedIndex = 0;
            checkedListBox1.SetItemChecked(1, true);
            checkedListBox1.SetItemChecked(2, true);
            checkedListBox1.SetItemChecked(4, true);
            checkedListBox1.SetItemChecked(6, true);
            comboBox3.SelectedItem = comboBox3.Items[0];
            g = panel1.CreateGraphics();
            panel1.BackColor = Color.White;
            panel2.BackColor = Color.Black;
            panel3.BackColor = Color.Black;
            g.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            colorDialog1.Color = Color.Black;
            colorDialog2.Color = Color.Black;
            trackBar2.Maximum = panel1.Bounds.Width;
            trackBar3.Maximum = panel1.Bounds.Height;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GenerateFigures(Convert.ToInt16(textBox1.Text));
            Draw();
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            g.Clear(Color.White);
            Draw();
            Figure tmp;
            string typeName = comboBox1.SelectedItem.ToString().Substring(0, comboBox1.SelectedItem.ToString().IndexOf('_'));
            int index = Convert.ToInt16(comboBox1.SelectedItem.ToString().Substring(comboBox1.SelectedItem.ToString().IndexOf('_') + 1));
            tmp = figures[typeName][index];
            Pen arrow = new Pen(Color.Black, 3);
            Point _1, _2, _3, _4;
            if (tmp.GetType() != typeof(Dot))
            {
                _1 = new Point(tmp.position.X + tmp.size.X / 2, tmp.position.Y - 5);
                _2 = new Point(tmp.position.X + tmp.size.X / 2, tmp.position.Y - 50);
                _3 = new Point(tmp.position.X + tmp.size.X / 2 + 10, tmp.position.Y - 20);
                _4 = new Point(tmp.position.X + tmp.size.X / 2 - 10, tmp.position.Y - 20);
            }
            else
            {
                _1 = new Point(tmp.position.X + 2, tmp.position.Y - 5);
                _2 = new Point(tmp.position.X + 2, tmp.position.Y - 50);
                _3 = new Point(tmp.position.X + 12, tmp.position.Y - 20);
                _4 = new Point(tmp.position.X - 8, tmp.position.Y - 20);
            }
            g.DrawLine(arrow, _1, _2);
            g.DrawLine(arrow, _1, _3);
            g.DrawLine(arrow, _1, _4);



            if (tmp.filled)
            {
                radioButton2.Checked = true;
            }
            else
            {
                radioButton1.Checked = true;
            }

            colorDialog1.Color = tmp.pen.Color;
            panel2.BackColor = colorDialog1.Color;
            colorDialog2.Color = tmp.brush.Color;
            panel3.BackColor = colorDialog2.Color;

            switch (tmp.pen.DashStyle)
            {
                case System.Drawing.Drawing2D.DashStyle.Solid:
                    comboBox3.SelectedIndex = 0;
                    break;
                case System.Drawing.Drawing2D.DashStyle.Dot:
                    comboBox3.SelectedIndex = 1;
                    break;
                case System.Drawing.Drawing2D.DashStyle.DashDotDot:
                    comboBox3.SelectedIndex = 2;
                    break;
                case System.Drawing.Drawing2D.DashStyle.DashDot:
                    comboBox3.SelectedIndex = 3;
                    break;
                case System.Drawing.Drawing2D.DashStyle.Dash:
                    comboBox3.SelectedIndex = 4;
                    break;
            }

            textBox2.Text = tmp.pen.Width.ToString();
            textBox3.Text = tmp.position.X.ToString();
            textBox4.Text = tmp.position.Y.ToString();
            textBox5.Text = tmp.size.X.ToString();
            textBox6.Text = tmp.size.Y.ToString();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (comboBox1.Items.Count > 0)
            {
                Figure tmp;
                string typeName = comboBox1.SelectedItem.ToString().Substring(0, comboBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(comboBox1.SelectedItem.ToString().Substring(comboBox1.SelectedItem.ToString().IndexOf('_') + 1));
                tmp = figures[typeName][index];
                if (radioButton2.Checked)
                {
                    tmp.filled = true;
                }
                else
                {
                    tmp.filled = false;
                }

                tmp.pen.Color = colorDialog1.Color;
                tmp.brush.Color = colorDialog2.Color;

                switch (comboBox3.SelectedIndex)
                {
                    case 0:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                        break;
                    case 1:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                        break;
                    case 2:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                        break;
                    case 3:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
                        break;
                    case 4:
                        tmp.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                        break;
                }

                tmp.pen.Width = Convert.ToInt16(textBox2.Text);
                tmp.position.X = Convert.ToInt16(textBox3.Text);
                tmp.position.Y = Convert.ToInt16(textBox4.Text);
                tmp.size.X = Convert.ToInt16(textBox5.Text);
                tmp.size.Y = Convert.ToInt16(textBox6.Text);
                figures[typeName][index] = tmp;
                Draw();
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (comboBox1.Items.Count > 0)
            {
                string typeName = comboBox1.SelectedItem.ToString().Substring(0, comboBox1.SelectedItem.ToString().IndexOf('_'));
                int index = Convert.ToInt16(comboBox1.SelectedItem.ToString().Substring(comboBox1.SelectedItem.ToString().IndexOf('_') + 1));
                if (figures.ContainsKey(typeName) && figures[typeName].Count > 0)
                {
                    figures[typeName].Remove(figures[typeName][index]);
                }
                List<string> list = figures.Keys.ToList();
                list.Sort();
                comboBox1.Items.Clear();
                foreach (string str in list)
                {
                    foreach (Figure fig in figures[str])
                    {
                        comboBox1.Items.Add(fig.ToString() + "_" + figures[fig.ToString()].IndexOf(fig));
                    }
                }
                if (comboBox1.Items.Count > 0)
                {
                    comboBox1.SelectedIndex = 0;
                }
                Draw();
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            foreach (string str in figures.Keys)
            {
                figures[str].Clear();
            }
            comboBox1.Items.Clear();
            comboBox1.Text = "";
            Draw();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AddCustom();
        }

        private void panel2_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel2.BackColor = colorDialog1.Color;
            }
        }

        private void panel3_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog2.ShowDialog() == DialogResult.OK)
            {
                panel3.BackColor = colorDialog2.Color;
            }
        }

        void GenerateFigures(int am)
        {
            List<Type> selectedTypes = new List<Type>();
            foreach (int selected in checkedListBox1.CheckedIndices)
            {
                selectedTypes.Add(intToType[selected]);
            }
            figures.Clear();
            comboBox1.Items.Clear();
            int amount = am;

            if (amount > 0)
            {
                dynamic tmpFigure;
                for (int i = 0; i < amount; i++)
                {

                    tmpFigure = Activator.CreateInstance(selectedTypes[rand.Next(0, selectedTypes.Count)]);

                    tmpFigure.position = new Point(rand.Next(0, 400), rand.Next(0, 200));
                    tmpFigure.size = new Point(rand.Next(10, 100), rand.Next(10, 100));
                    tmpFigure.pen = GetRandomPen();
                    tmpFigure.brush = GetRandomBrush();
                    tmpFigure.filled = rand.Next(0, 2) > 0 ? true : false;

                    if (!figures.ContainsKey(tmpFigure.ToString()))
                    {
                        figures.Add(tmpFigure.ToString(), new List<Figure>());
                    }

                    figures[tmpFigure.ToString()].Add(tmpFigure);
                }

                List<string> list = figures.Keys.ToList();
                list.Sort();
                foreach (string str in list)
                {
                    foreach (Figure fig in figures[str])
                    {
                        comboBox1.Items.Add(fig.ToString() + "_" + figures[fig.ToString()].IndexOf(fig));
                    }
                }
                comboBox1.SelectedIndex = 0;

            }
        }

        void AddCustom()
        {
            dynamic tmpFigure;
            tmpFigure = Activator.CreateInstance(intToType[comboBox2.SelectedIndex]);
            tmpFigure.position = new Point(Convert.ToInt16(textBox3.Text), Convert.ToInt16(textBox4.Text));
            tmpFigure.size = new Point(Convert.ToInt16(textBox5.Text), Convert.ToInt16(textBox6.Text));
            tmpFigure.pen = new Pen(colorDialog1.Color, Convert.ToInt16(textBox2.Text));
            switch (comboBox3.SelectedIndex)
            {
                case 0:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    break;
                case 1:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                    break;
                case 2:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                    break;
                case 3:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
                    break;
                case 4:
                    tmpFigure.pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    break;
            }
            tmpFigure.brush = new SolidBrush(colorDialog2.Color);
            tmpFigure.filled = radioButton2.Checked ? true : false;
            if (!figures.ContainsKey(tmpFigure.ToString()))
            {
                figures.Add(tmpFigure.ToString(), new List<Figure>());
            }

            figures[tmpFigure.ToString()].Add(tmpFigure);

            List<string> list = figures.Keys.ToList();
            list.Sort();
            comboBox1.Items.Clear();
            foreach (string str in list)
            {
                foreach (Figure fig in figures[str])
                {
                    comboBox1.Items.Add(fig.ToString() + "_" + figures[fig.ToString()].IndexOf(fig));
                }
            }
            comboBox1.SelectedIndex = 0;
            Draw();
        }

        void Draw()
        {
            g.Clear(Color.White);
            foreach (string str in figures.Keys)
            {
                foreach (Figure fig in figures[str])
                {
                    fig.Draw(g); 
                }
            }
        }

        Pen GetRandomPen()
        {
            Pen pen = new Pen(Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255)),(float)rand.Next(0,5));
            switch (rand.Next(0, 5))
            {
                case 0:
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Solid;
                    break;
                case 1:
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dot;
                    break;
                case 2:
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                    break;
                case 3:
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.DashDot;
                    break;
                case 4:
                    pen.DashStyle = System.Drawing.Drawing2D.DashStyle.Dash;
                    break;
            }
            return pen;
        }

        SolidBrush GetRandomBrush()
        {
            return new SolidBrush(Color.FromArgb(rand.Next(0, 255), rand.Next(0, 255), rand.Next(0, 255)));
        }

        private void TextChanged(object sender, EventArgs e)
        {
            try
            {
                trackBar1.Value = Convert.ToInt16(textBox2.Text);
                trackBar2.Value = Convert.ToInt16(textBox3.Text);
                trackBar3.Value = Convert.ToInt16(textBox4.Text);
                trackBar4.Value = Convert.ToInt16(textBox5.Text);
                trackBar5.Value = Convert.ToInt16(textBox6.Text);
            }
            catch { }
        }

        private void trackBarValueChanged(object sender, EventArgs e)
        {
            textBox2.Text = trackBar1.Value.ToString();
            textBox3.Text = trackBar2.Value.ToString();
            textBox4.Text = trackBar3.Value.ToString();
            textBox5.Text = trackBar4.Value.ToString();
            textBox6.Text = trackBar5.Value.ToString();
        }



        

    }
}
