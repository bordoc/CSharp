﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt3Harkavyi44578
{
    public partial class Form1 : Form
    {
        Graphics g, gMap, gBuff;
        Bitmap map, buff;
        Font axesTextFont;
        SolidBrush textColor = new SolidBrush(Color.Black);
        Pen axesLine = new Pen(Color.Black, 3);
        Pen firstLine = new Pen(Color.Red, 2);
        Pen secondLine = new Pen(Color.Green, 2);
        List<Point> path1 = new List<Point>(), path2 = new List<Point>();
        int obj1pos = 0, obj2pos = 0;
        Figure obj1, obj2;

        public Form1()
        {
            InitializeComponent();
            g = panel0.CreateGraphics();
            map = new Bitmap(panel0.Bounds.Width, panel0.Bounds.Height);
            buff = new Bitmap(panel0.Bounds.Width, panel0.Bounds.Height);
            axesTextFont = new Font(this.Font, this.Font.Style);
            gMap = Graphics.FromImage(map);
            gMap.Clear(Color.Transparent);
            gBuff = Graphics.FromImage(buff);
            obj1 = new Figure(new Point(10, 10), Color.Black);
            obj2 = new Figure(new Point(10, 10), Color.Black);
            comboBox1.SelectedIndex = comboBox2.SelectedIndex = comboBox3.SelectedIndex = comboBox4.SelectedIndex = 0;
            firstLine.DashStyle = GetLineStyle(comboBox1.SelectedText);
            secondLine.DashStyle = GetLineStyle(comboBox2.SelectedText);
            axesLine.DashStyle = GetLineStyle(comboBox3.SelectedText);
            axesLine.EndCap = GetLineCap(comboBox4.SelectedText);
            panel1.BackColor = firstLine.Color;
            panel2.BackColor = secondLine.Color;
            panel3.BackColor = panel0.BackColor;
            panel4.BackColor = axesLine.Color;
            panel5.BackColor = textColor.Color;
            trackBar2.Value = obj1.speed;
            trackBar4.Value = obj2.speed;
            Generate();
            DrawMap();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            fontDialog1.ShowDialog();
            axesTextFont = fontDialog1.Font;
            DrawMap();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {
            Draw();
        }

        void Draw()
        {
            gBuff.Clear(panel0.BackColor);
            gBuff.DrawImage(map, 0, 0);
            obj1.Draw(gBuff);
            obj2.Draw(gBuff);
            g.DrawImage(buff, 0, 0);
        }

        void DrawMap()
        {
            gMap.Clear(Color.Transparent);
            gMap.DrawLine(axesLine, new Point(0, panel0.Bounds.Height / 2),
                new Point(panel0.Bounds.Width - 10, panel0.Bounds.Height / 2));
            gMap.DrawLine(axesLine, new Point(panel0.Bounds.Width / 2, panel0.Bounds.Height),
                new Point(panel0.Bounds.Width / 2, 10));
            gMap.DrawLines(firstLine, path1.ToArray());
            gMap.DrawLines(secondLine, path2.ToArray());
            gMap.DrawString("Y", axesTextFont, textColor, new Point(panel0.Bounds.Width / 2 - 15, 20));
            gMap.DrawString("X", axesTextFont, textColor, new Point(panel0.Bounds.Width - 30, panel0.Bounds.Height / 2 - 20));
        }
        void Generate()
        {
            for (int x = 0; x < panel0.Bounds.Width; x++)
            {
                path1.Add(new Point(x, (int)(float)(Math.Sin((float)(x - panel0.Bounds.Width / 2) / 32) * 80 + panel0.Bounds.Height / 2)));
                path2.Add(new Point(x, (int)(float)(Math.Cos((float)(x - panel0.Bounds.Width / 2) / 32) * 80 + panel0.Bounds.Height / 2)));
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            obj1pos += obj1.speed;
            if (path1.Count > obj1pos)
            {
                obj1.position = path1[obj1pos];
            }
            else
            {
                obj1pos = 0;
                obj1.position = path1[obj1pos];
            }
            obj2pos += obj2.speed;
            if (path2.Count > obj2pos)
            {
                obj2.position = path2[obj2pos];
            }
            else
            {
                obj2pos = 0;
                obj2.position = path2[obj2pos];
            }
            Draw();
        }

        private void panel1_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel1.BackColor = colorDialog1.Color;
                firstLine.Color = panel1.BackColor;
                DrawMap();
            }
        }

        private void panel2_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel2.BackColor = colorDialog1.Color;
                secondLine.Color = panel2.BackColor;
                DrawMap();
            }
        }

        private void panel3_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel3.BackColor = colorDialog1.Color;
                panel0.BackColor = panel3.BackColor;
                DrawMap();
            }
        }

        private void panel4_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel4.BackColor = colorDialog1.Color;
                axesLine.Color = panel4.BackColor;
                DrawMap();

            }
        }

        private void panel5_MouseClick(object sender, MouseEventArgs e)
        {
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel5.BackColor = colorDialog1.Color;
                textColor = new SolidBrush(panel5.BackColor);
                DrawMap();
            }
        }

        private void trackBar2_Scroll(object sender, EventArgs e)
        {
            obj1.speed = trackBar2.Value;
        }

        private void trackBar4_Scroll(object sender, EventArgs e)
        {
            obj2.speed = trackBar4.Value;
        }

        System.Drawing.Drawing2D.LineCap GetLineCap(string text)
        {
            System.Drawing.Drawing2D.LineCap status;
            switch (text)
            {
                case "ArrowAnchor":
                    status = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                    break;
                case "Round":
                    status = System.Drawing.Drawing2D.LineCap.Round;
                    break;
                case "DiamondAnchor":
                    status = System.Drawing.Drawing2D.LineCap.DiamondAnchor;
                    break;
                case "Square":
                    status = System.Drawing.Drawing2D.LineCap.Square;
                    break;
                default:
                    status = System.Drawing.Drawing2D.LineCap.ArrowAnchor;
                    break;
            }
            return status;
        }

        System.Drawing.Drawing2D.DashStyle GetLineStyle(string text)
        {
            System.Drawing.Drawing2D.DashStyle status;
            switch (text)
            {
                case "Dash":
                    status = System.Drawing.Drawing2D.DashStyle.Dash;
                    break;
                case "Dot":
                    status = System.Drawing.Drawing2D.DashStyle.Dot;
                    break;
                case "DashDot":
                    status = System.Drawing.Drawing2D.DashStyle.DashDot;
                    break;
                case "DashDotDot":
                    status = System.Drawing.Drawing2D.DashStyle.DashDotDot;
                    break;
                default:
                    status = System.Drawing.Drawing2D.DashStyle.Solid;
                    break;
            }
            return status;
            /*
            firstLine.DashStyle = GetLineStyle(comboBox1.SelectedText);
            secondLine.DashStyle = GetLineStyle(comboBox2.SelectedText);
            axesLine.DashStyle = GetLineStyle(comboBox3.SelectedText);
            axesLine.EndCap = GetLineCap(comboBox4.SelectedText);
            if (path1.Count > 0)
            {
                DrawMap();
            }*/
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            firstLine.DashStyle = GetLineStyle(comboBox1.SelectedItem.ToString());
            if (path1.Count > 0)
            {
                DrawMap();
            }
        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            secondLine.DashStyle = GetLineStyle(comboBox2.SelectedItem.ToString());
            if (path1.Count > 0)
            {
                DrawMap();
            }
        }

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            axesLine.DashStyle = GetLineStyle(comboBox3.SelectedItem.ToString());
            if (path1.Count > 0)
            {
                DrawMap();
            }
        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            axesLine.EndCap = GetLineCap(comboBox4.SelectedItem.ToString());
            if (path1.Count > 0)
            {
                DrawMap();
            }
        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {
            firstLine.Width = trackBar1.Value;
            DrawMap();
        }

        private void trackBar3_Scroll(object sender, EventArgs e)
        {
            secondLine.Width = trackBar3.Value;
            DrawMap();
        }

        private void trackBar5_Scroll(object sender, EventArgs e)
        {
            axesLine.Width = trackBar5.Value;
            DrawMap();
        }
    }
}
