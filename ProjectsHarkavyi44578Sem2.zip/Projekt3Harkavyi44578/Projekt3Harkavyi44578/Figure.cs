﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Drawing;

namespace Projekt3Harkavyi44578
{
    class Figure
    {
        public Point position = new Point();
        public int speed = 5;
        Point size;
        Color color;
        public Figure(Point s, Color col)
        {
            size = s;
            color = col;
        }

        public void Draw(Graphics g)
        {
            g.FillEllipse(new SolidBrush(color), position.X - size.X / 2, position.Y - size.Y / 2, size.X, size.Y); 
        }
    }
}
